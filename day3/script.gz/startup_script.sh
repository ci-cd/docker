#!/bin/bash
date
# java -jar jenkins.war